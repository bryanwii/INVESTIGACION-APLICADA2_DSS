<?php
require 'vendor/autoload.php';
require 'database.php'; // Archivo de configuración de conexión a la base de datos

use React\Http\HttpServer;
use React\Http\Message\Response;
use React\Socket\SocketServer;
use React\EventLoop\Loop;
use Psr\Http\Message\ServerRequestInterface;

// Configuración del servidor
$server = new HttpServer(function (ServerRequestInterface $request) {
    $path = $request->getUri()->getPath();

    switch ($path) {
        case '/data':
            if ($request->getMethod() === 'GET') {
                // Operación READ: Mostrar todas las entradas
                global $pdo;
                try {
                    $stmt = $pdo->query("SELECT * FROM contactos");
                    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    return new Response(200, ['Content-Type' => 'application/json'], json_encode($data));
                } catch (PDOException $e) {
                    return new Response(500, ['Content-Type' => 'text/plain'], 'Error al consultar la base de datos: ' . $e->getMessage());
                }
            } elseif ($request->getMethod() === 'POST') {
                // Operación CREATE: Crear una nueva entrada
                $postData = $request->getParsedBody();
                $nombre = $postData['name'] ?? '';
                $correo = $postData['email'] ?? '';
                $mensaje = $postData['message'] ?? '';

                global $pdo;
                try {
                    $sql = "INSERT INTO contactos (nombre, correo, mensaje) VALUES (:nombre, :correo, :mensaje)";
                    $stmt = $pdo->prepare($sql);
                    $stmt->execute([
                        ':nombre' => $nombre,
                        ':correo' => $correo,
                        ':mensaje' => $mensaje
                    ]);
                    return new Response(201, ['Content-Type' => 'text/plain'], 'Entrada creada correctamente.');
                } catch (PDOException $e) {
                    return new Response(500, ['Content-Type' => 'text/plain'], 'Error al crear la entrada: ' . $e->getMessage());
                }
            } elseif ($request->getMethod() === 'PUT') {
                // Operación UPDATE: Actualizar una entrada existente
                $postData = $request->getParsedBody();
                $id = $postData['id'] ?? 0;
                $nombre = $postData['name'] ?? '';
                $correo = $postData['email'] ?? '';
                $mensaje = $postData['message'] ?? '';

                global $pdo;
                try {
                    $sql = "UPDATE contactos SET nombre = :nombre, correo = :correo, mensaje = :mensaje WHERE id = :id";
                    $stmt = $pdo->prepare($sql);
                    $stmt->execute([
                        ':nombre' => $nombre,
                        ':correo' => $correo,
                        ':mensaje' => $mensaje,
                        ':id' => $id
                    ]);
                    return new Response(200, ['Content-Type' => 'text/plain'], 'Entrada actualizada correctamente.');
                } catch (PDOException $e) {
                    return new Response(500, ['Content-Type' => 'text/plain'], 'Error al actualizar la entrada: ' . $e->getMessage());
                }
            } elseif ($request->getMethod() === 'DELETE') {
                // Operación DELETE: Eliminar una entrada existente
                $postData = $request->getParsedBody();
                $id = $postData['id'] ?? 0;

                global $pdo;
                try {
                    $sql = "DELETE FROM contactos WHERE id = :id";
                    $stmt = $pdo->prepare($sql);
                    $stmt->execute([':id' => $id]);
                    return new Response(200, ['Content-Type' => 'text/plain'], 'Entrada eliminada correctamente.');
                } catch (PDOException $e) {
                    return new Response(500, ['Content-Type' => 'text/plain'], 'Error al eliminar la entrada: ' . $e->getMessage());
                }
            } else {
                // Método no soportado
                return new Response(405, ['Content-Type' => 'text/plain'], 'Método no permitido.');
            }

        default:
            // Ruta no encontrada
            return new Response(404, ['Content-Type' => 'text/plain'], 'Página no encontrada.');
    }
});

// Configurar el bucle de eventos y el servidor
$loop = Loop::get();
$socket = new SocketServer('127.0.0.1:3000', [], $loop);

// Enlazar el servidor HTTP al socket
$server->listen($socket);

echo "Servidor ejecutándose en http://localhost:3000\n";