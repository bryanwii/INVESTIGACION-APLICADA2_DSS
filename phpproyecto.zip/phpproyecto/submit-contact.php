<?php
// Habilitar reporte de errores para depuración
error_reporting(E_ALL);
ini_set('display_errors', 1);

require 'database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = $_POST['name'] ?? '';
    $correo = $_POST['email'] ?? '';
    $mensaje = $_POST['message'] ?? '';

    try {
        $sql = "INSERT INTO contactos (nombre, correo, mensaje) VALUES (:nombre, :correo, :mensaje)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':nombre' => $nombre,
            ':correo' => $correo,
            ':mensaje' => $mensaje
        ]);

        echo "¡Gracias por tu mensaje! Se ha enviado correctamente.";
    } catch (PDOException $e) {
        echo "Error al enviar el mensaje: " . $e->getMessage();
    }
} else {
    echo "Método de solicitud no válido.";
}
?>